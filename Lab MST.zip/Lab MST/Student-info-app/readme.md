Reusable Student info card 
